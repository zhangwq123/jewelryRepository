package com.jewelry.config;


import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.serializer.SerializerFeature;

/**
 * 本系统json  格式输出统一报文格式
 * @author zwq
 *
 */
public class JsonObjectOutPutFmtUtil {
	
	public static String jsonFormat(Object data){
		String str = JSONObject.toJSONString(data,
				SerializerFeature.WriteDateUseDateFormat,
				SerializerFeature.WriteMapNullValue);
		return str;
	}

}
