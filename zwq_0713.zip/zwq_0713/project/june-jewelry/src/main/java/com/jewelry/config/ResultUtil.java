package com.jewelry.config;

import com.jewelry.config.dto.ResultDTO;

/**
 * ajax 统一报文处理工具
 * @author zwq
 *
 */
public class ResultUtil {

	/**
	 * 处理成功
	 * 
	 * @param data
	 * @return SYS_OK("M0000", "响应成功") STT_SUCCESS("0", "SUCCESS")
	 */
	public static ResultDTO success(Object data) {

		return delMsg(SysConstantEnum.SYS_OK.getCode(), SysConstantEnum.SYS_OK.getMsg(),
				SysConstantEnum.STT_SUCCESS.getCode(), SysConstantEnum.STT_SUCCESS.getMsg(), data);

	}

	/**
	 * 处理失败
	 * 
	 * @param data
	 * @return
	 */
	public static ResultDTO fail(Object data, String errcode, String errmsg, String msg) {

		return delMsg(errcode, errmsg, SysConstantEnum.STT_FAILED.getCode(), msg, data);

	}

	/**
	 * 处理可疑 SYS_DOUBT("D0000", "系统异常")
	 * 
	 * @param data
	 * @return
	 */
	public static ResultDTO doubt(Object data, String msg) {

		return delMsg(SysConstantEnum.SYS_DOUBT.getCode(), SysConstantEnum.SYS_DOUBT.getMsg(),
				SysConstantEnum.STT_FAILED.getCode(), msg, data);

	}

	/**
	 * @param errcode
	 * @param errmsg
	 * @param stt
	 * @param msg
	 * @param obj
	 *            数据域
	 * @return 统一报文格式
	 */
	public static ResultDTO delMsg(String errcode, String errmsg, String stt, String msg, Object obj) {
		ResultDTO dto = new ResultDTO();
		// 头信息
		dto.setHead(errcode, errmsg);
		// 体信息
		dto.setBody(obj, stt, msg);
		return dto;
	}

}
