package com.jewelry.config;

import java.util.concurrent.ConcurrentHashMap;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;


/**
 * 系统缓存
 * @author zwq
 *
 */
@Component
public final class SysCache {
	Logger logger = Logger.getLogger(SysCache.class);
	/**
	 * KEY:jsessionid+session创建时间
	 * 当前登录用户数集合
	 */
	public static final ConcurrentHashMap<String, Boolean> LOGIN_USER_NUM_CMP = new ConcurrentHashMap<String, Boolean>();
	
	
	/**
	 * 初始化缓存	读表
	 */
	public  void init(){
		
	}
	
	
}
