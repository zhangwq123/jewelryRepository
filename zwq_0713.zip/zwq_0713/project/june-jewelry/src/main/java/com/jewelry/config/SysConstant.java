package com.jewelry.config;

/**
 * 系统常量
 * @author zwq
 *
 */
public class SysConstant {
	/**
	 * 默认分页  大小
	 */
	public static final Integer DEFAULT_PAGE_SIZE=10;
	/**
	 * 控制器返回值,放入req  对象固定  key字段名
	 */
	public static final String DATA="jewelry_data_key";
	/**
	 * 统一报文头根字段名
	 */
	public static final String RESP_HEAD_NAME="head";
	
	/**
	 * 统一报文体根字段名
	 */
	public static final String RESP_BODY_NAME="body";
	/**
	 * 统一报文头错误码字段名
	 */
	public static final String ERR_CODE_NAME="errcode";
	/**
	 * 统一报文头错误信息字段名
	 */
	public static final String ERR_MSG_NAME="errmsg";
	/**
	 * 统一报文体业务状态码字段名
	 */
	public static final String BSY_CODE_NAME="stt";
	/**
	 * 统一报文体业务信息字段名
	 */
	public static final String BSY_MSG_NAME="msg";
	/**
	 * 统一报文体业务信息字段名
	 */
	public static final String BSY_DATA_NAME="data";
	/**
	 * 统一报文体具体信息字段名
	 */
	public static final String BSY_DATA_INFO_NAME="info";
	/**
	 * 统一报文体具体信息总条数字段名
	 */
	public static final String BSY_DATA_TOTAL_NAME="totalNum";
	/**
	 * 统一报文体业务处理成功值  
	 */
	public static final String BSY_STT_SUCCESS_VALUE="0";
	/**
	 * 统一报文体业务处理处理可疑值  
	 */
	public static final String BSY_STT_DOUBT_VALUE="1";
	/**
	 * 统一报文体业务处理处理失败值  
	 */
	public static final String BSY_STT_FAIL_VALUE="2";
	/**
	 * 统一报文体业务处理处理处理中值  
	 */
	public static final String BSY_STT_DEL_VALUE="3";
}
