package com.jewelry.config;

/**
 * 公共系统常量
 * 
 * @author zwq
 *
 */
public enum SysConstantEnum {
	/**
	 * 报文头错误码，错误信息定义
	 */
	SYS_OK("M0000", "响应成功"),

	/**
	 * 报文头错误码，错误信息定义
	 */
	SYS_ERR("E0000", "系统错误"), VALIDATE_ERR("E1001", "参数格式校验失败"), DATABASE_ERR("E1002", "数据库异常"), LOGIN_VALIDATE_FAIL("E1003", "用户名或密码错误"),
	SYS_NO_LOGIN("E1004", "未登录"), SYS_ILLEGAL_USER("E1004", "非法用户"),
	/**
	 * 报文头错误码，错误信息定义 系统异常
	 */
	SYS_DOUBT("D0000", "系统异常"),

	/**
	 * 报文体业务状态码，状态信息定义
	 */
	STT_SUCCESS("0", "SUCCESS"), STT_DOUBT("1", "业务处理异常"), STT_FAILED("2", "业务处理失败"), STT_DEAL("3", "业务处理中");

	private String errcode;
	private String errmsg;

	private SysConstantEnum(String errcode, String errmsg) {
		this.errcode = errcode;
		this.errmsg = errmsg;
	}

	public String getCode() {
		return errcode;
	}

	public void setCode(String code) {
		this.errcode = code;
	}

	public String getMsg() {
		return errmsg;
	}

	public void setMsg(String msg) {
		this.errmsg = msg;
	}

	public static void main(String[] args) {
		System.out.println(SysConstantEnum.STT_SUCCESS.errcode);
	}

}
