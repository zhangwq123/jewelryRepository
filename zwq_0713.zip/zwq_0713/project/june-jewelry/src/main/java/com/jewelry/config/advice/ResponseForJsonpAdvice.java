package com.jewelry.config.advice;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.core.MethodParameter;
import org.springframework.http.MediaType;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.server.ServerHttpRequest;
import org.springframework.http.server.ServerHttpResponse;
import org.springframework.http.server.ServletServerHttpRequest;
import org.springframework.http.server.ServletServerHttpResponse;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.servlet.mvc.method.annotation.ResponseBodyAdvice;

import com.alibaba.fastjson.JSON;
import com.jewelry.config.JsonObjectOutPutFmtUtil;
import com.jewelry.util.Utils;

@ControllerAdvice(basePackages = "com.jewelry.controller")
public class ResponseForJsonpAdvice implements ResponseBodyAdvice<Object> {

	@Override
	public Object beforeBodyWrite(Object result, MethodParameter mp, MediaType mt,
			Class<? extends HttpMessageConverter<?>> arg3, ServerHttpRequest serverRequest, ServerHttpResponse serverResponse) {
		
		HttpServletResponse response = ((ServletServerHttpResponse) serverResponse).getServletResponse();
		HttpServletRequest request = ((ServletServerHttpRequest) serverRequest).getServletRequest();
		
		String callbackMethod = request.getParameter("callback");
		Utils.responseMessage(response, callbackMethod + "(" + JsonObjectOutPutFmtUtil.jsonFormat(result) + ")");
		
		return null;
	}

	@Override
	public boolean supports(MethodParameter arg0, Class<? extends HttpMessageConverter<?>> arg1) {
		return true;
	}

}
