package com.jewelry.config.dto;

import com.jewelry.config.SysConstantEnum;

/**
 * @author liusw
 * 数据传输对象
 */
public class ResultDTO {

	private Head head;
	
	private Body body;
	
	public Head getHead() {
		return head;
	}

	public void setHead(String code, String msg) {
		this.head = new Head(code, msg);
	}

	public Body getBody() {
		return body;
	}

	public void setBody(Object data) {
		this.setBody(data, SysConstantEnum.SYS_OK.getCode(), SysConstantEnum.SYS_OK.getMsg());
	}
	
	public void setBody(Object data, String stt, String msg) {
		this.body = new Body(data, stt, msg);
	}

	private class Head {
		private String code;
		private String msg;
		
		public Head(String code, String msg) {
			this.code = code;
			this.msg = msg;
		}

		@SuppressWarnings("unused")
		public String getCode() {
			return code;
		}

		@SuppressWarnings("unused")
		public String getMsg() {
			return msg;
		}

	}
	
	private class Body {
		private Object data;
		private String stt;
		private String msg;
		
		public Body(Object data, String stt, String msg) {
			this.data = data;
			this.stt = stt;
			this.msg = msg;
		}

		@SuppressWarnings("unused")
		public Object getData() {
			return data;
		}

		@SuppressWarnings("unused")
		public String getStt() {
			return stt;
		}

		@SuppressWarnings("unused")
		public String getMsg() {
			return msg;
		}
	}
}
