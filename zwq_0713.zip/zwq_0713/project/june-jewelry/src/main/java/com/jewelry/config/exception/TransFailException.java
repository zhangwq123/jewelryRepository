package com.jewelry.config.exception;

/**
 * 自定义失败异常
 * @author zwq
 *
 */
public class TransFailException extends RuntimeException {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String errCode;

	public TransFailException(String errCode, String errMsg) {
		super(errMsg);
		this.errCode = errCode;

	}

	public String getErrCode() {
		return errCode;
	}

	@Override
	public String getMessage() {
		return super.getMessage();
	}

}
