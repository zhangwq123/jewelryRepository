package com.jewelry.config.interceptor;

import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;

import com.jewelry.config.SysConstantEnum;
import com.jewelry.config.dto.ResultDTO;
import com.jewelry.config.exception.TransFailException;

/**
 * 统一异常拦截处理
 * 
 * @author zwq
 *
 */
@ControllerAdvice
public class DefaultExceptionHandler {
	Logger logger = Logger.getLogger(DefaultExceptionHandler.class);

	@ExceptionHandler
	@ResponseBody
	public ResultDTO errResult(Exception e, HttpServletResponse resp) {
		// 默认返回错误信息
		String errcode = SysConstantEnum.SYS_ERR.getCode();
		String errmsg = SysConstantEnum.SYS_ERR.getMsg();
		if (e instanceof TransFailException) {
			TransFailException e1 = (TransFailException) e;
			errcode = e1.getErrCode();
			errmsg = e1.getMessage();
		}
		logger.error("errResult出错:", e);
		
		// 异常默认返回固定报文信息
		ResultDTO errDto = new ResultDTO();
		errDto.setHead(errcode, errmsg);
		
		return errDto;
	}

}
