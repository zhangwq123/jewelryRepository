package com.jewelry.config.interceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import com.alibaba.fastjson.JSON;
import com.jewelry.config.JsonObjectOutPutFmtUtil;
import com.jewelry.config.SysConstantEnum;
import com.jewelry.config.dto.ResultDTO;
import com.jewelry.util.Utils;

/**
 * @author liusw
 * 身份认证
 */
public class IDAuthenticateInterceptor implements HandlerInterceptor {

	private static Logger logger = Logger.getLogger(IDAuthenticateInterceptor.class);
	
	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object obj) throws Exception {
		HttpSession session = request.getSession(false);
		if (session == null||session.getAttribute("user")==null) {
			logger.info("未登录");
			
			ResultDTO errorData = new ResultDTO();
			errorData.setHead(SysConstantEnum.SYS_NO_LOGIN.getCode(), SysConstantEnum.SYS_NO_LOGIN.getMsg());
			
			Utils.responseMessage(response, request.getParameter("callback") + "(" + JsonObjectOutPutFmtUtil.jsonFormat(errorData) + ")");
			return false;
		}
		
		return true;
	}

	@Override
	public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object obj, Exception e)
			throws Exception {

	}

	@Override
	public void postHandle(HttpServletRequest request, HttpServletResponse response, Object obj, ModelAndView mv)
			throws Exception {
	}

}
