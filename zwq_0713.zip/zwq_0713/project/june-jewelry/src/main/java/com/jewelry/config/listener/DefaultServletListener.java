package com.jewelry.config.listener;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import org.apache.log4j.Logger;

/**
 * web应用程序启动监听器
 * @author zwq
 *
 */
public class DefaultServletListener implements ServletContextListener{
	
	Logger logger = Logger.getLogger(DefaultServletListener.class);
	@Override
	public void contextInitialized(ServletContextEvent paramServletContextEvent) {
		logger.info("系统初始化系统参数------DefaultServletListener--------------");
		//初始化缓存
		
	}

	@Override
	public void contextDestroyed(ServletContextEvent paramServletContextEvent) {
		logger.info("系统释放资源------DefaultServletListener------------");
		//释放缓存
		
	}

}
