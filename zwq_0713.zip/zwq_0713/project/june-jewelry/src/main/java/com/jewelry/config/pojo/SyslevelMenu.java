package com.jewelry.config.pojo;

/**
 * 系统级别菜单集合
 * @author zwq
 *
 */
public class SyslevelMenu {
	private String le_id;//主键id
	private String le_name;//系统级别名称
	private String le_menuid;//菜单id集合
	private String le_createdate;//创建日期YYYYMMDD
	private String le_updatetime;//最后修改时间
	public String getLe_id() {
		return le_id;
	}
	public void setLe_id(String le_id) {
		this.le_id = le_id;
	}
	public String getLe_name() {
		return le_name;
	}
	public void setLe_name(String le_name) {
		this.le_name = le_name;
	}
	public String getLe_menuid() {
		return le_menuid;
	}
	public void setLe_menuid(String le_menuid) {
		this.le_menuid = le_menuid;
	}
	public String getLe_createdate() {
		return le_createdate;
	}
	public void setLe_createdate(String le_createdate) {
		this.le_createdate = le_createdate;
	}
	public String getLe_updatetime() {
		return le_updatetime;
	}
	public void setLe_updatetime(String le_updatetime) {
		this.le_updatetime = le_updatetime;
	}
	@Override
	public String toString() {
		return "SyslevelMenu [le_id=" + le_id + ", le_name=" + le_name + ", le_menuid=" + le_menuid + ", le_createdate=" + le_createdate
				+ ", le_updatetime=" + le_updatetime + "]";
	}
	
	
	

}
