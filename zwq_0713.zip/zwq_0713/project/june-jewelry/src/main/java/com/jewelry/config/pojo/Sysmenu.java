package com.jewelry.config.pojo;

import java.util.List;

/**
 * 系统菜单
 * @author zwq
 *
 */
public class Sysmenu {
	private String mn_id;//主键id
	private String mn_pid;//父级菜单id,默认是一级菜单0
	private String mn_name;//菜单名称
	private String mn_url;//菜单对应url
	private String mn_icon;//菜单对应图标url
	private String mn_oprname;//菜单对应操作名称
	private String mn_isparent;//是否是父菜单,0:父菜单;1:子菜单 
	private String mn_isshow;//是否显示菜单,0:显示;1:隐藏
	private String mn_sort;//菜单排序,默认为:0
	private String mn_createdate;//创建日期YYYYMMDD
	private String mn_updatetime;//最后修改时间
	private List<Sysmenu> childmenus;//子菜单
	
	
	public String getMn_isparent() {
		return mn_isparent;
	}
	public void setMn_isparent(String mn_isparent) {
		this.mn_isparent = mn_isparent;
	}
	public String getMn_id() {
		return mn_id;
	}
	public void setMn_id(String mn_id) {
		this.mn_id = mn_id;
	}
	public String getMn_pid() {
		return mn_pid;
	}
	public void setMn_pid(String mn_pid) {
		this.mn_pid = mn_pid;
	}
	public String getMn_name() {
		return mn_name;
	}
	public void setMn_name(String mn_name) {
		this.mn_name = mn_name;
	}
	public String getMn_url() {
		return mn_url;
	}
	public void setMn_url(String mn_url) {
		this.mn_url = mn_url;
	}
	public String getMn_icon() {
		return mn_icon;
	}
	public void setMn_icon(String mn_icon) {
		this.mn_icon = mn_icon;
	}
	public String getMn_oprname() {
		return mn_oprname;
	}
	public void setMn_oprname(String mn_oprname) {
		this.mn_oprname = mn_oprname;
	}
	public String getMn_isshow() {
		return mn_isshow;
	}
	public void setMn_isshow(String mn_isshow) {
		this.mn_isshow = mn_isshow;
	}
	public String getMn_sort() {
		return mn_sort;
	}
	public void setMn_sort(String mn_sort) {
		this.mn_sort = mn_sort;
	}
	public String getMn_createdate() {
		return mn_createdate;
	}
	public void setMn_createdate(String mn_createdate) {
		this.mn_createdate = mn_createdate;
	}
	public String getMn_updatetime() {
		return mn_updatetime;
	}
	public void setMn_updatetime(String mn_updatetime) {
		this.mn_updatetime = mn_updatetime;
	}
	
	public List<Sysmenu> getChildmenus() {
		return childmenus;
	}
	public void setChildmenus(List<Sysmenu> childmenus) {
		this.childmenus = childmenus;
	}
	
	public Sysmenu() {
		super();
	}
	public Sysmenu(String mn_id, String mn_pid, String mn_name, String mn_url, String mn_icon, String mn_oprname, String mn_isparent,
			String mn_isshow, String mn_sort, String mn_createdate, String mn_updatetime, List<Sysmenu> childmenus) {
		super();
		this.mn_id = mn_id;
		this.mn_pid = mn_pid;
		this.mn_name = mn_name;
		this.mn_url = mn_url;
		this.mn_icon = mn_icon;
		this.mn_oprname = mn_oprname;
		this.mn_isparent = mn_isparent;
		this.mn_isshow = mn_isshow;
		this.mn_sort = mn_sort;
		this.mn_createdate = mn_createdate;
		this.mn_updatetime = mn_updatetime;
		this.childmenus = childmenus;
	}
	@Override
	public String toString() {
		return "Sysmenu [mn_id=" + mn_id + ", mn_pid=" + mn_pid + ", mn_name=" + mn_name + ", mn_url=" + mn_url + ", mn_icon=" + mn_icon
				+ ", mn_oprname=" + mn_oprname + ", mn_isparent=" + mn_isparent + ", mn_isshow=" + mn_isshow + ", mn_sort=" + mn_sort
				+ ", mn_createdate=" + mn_createdate + ", mn_updatetime=" + mn_updatetime + ", childmenus=" + childmenus + "]";
	}
	

}
