package com.jewelry.controller;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.jewelry.config.ResultUtil;
import com.jewelry.config.dto.ResultDTO;
import com.jewelry.service.CompanyService;

@Controller
@RequestMapping("/company")
public class CompanyController {

	private final Logger logger = Logger.getLogger(CompanyController.class);
	
	@Autowired
	private CompanyService service;
	
	@RequestMapping("/query")
	@ResponseBody
	public ResultDTO queryCompanyInfo(@RequestParam(name = "coId", required = true) Integer coId) {
		logger.info("查看公司信息，公司ID：" + coId);
		
		return ResultUtil.success(service.queryInfoById(coId));
	}
}
