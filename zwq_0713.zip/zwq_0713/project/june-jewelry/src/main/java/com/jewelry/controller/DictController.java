package com.jewelry.controller;

import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.github.pagehelper.PageInfo;
import com.jewelry.config.ResultUtil;
import com.jewelry.config.SysConstant;
import com.jewelry.config.dto.ResultDTO;
import com.jewelry.service.DictService;

/**
 * 字典表相关操作
 * 
 * @author zwq
 *
 */
@Controller
@RequestMapping("/dict")
public class DictController {
	Logger logger = Logger.getLogger(DictController.class);

	@Autowired
	DictService dictService;

	// @RequestMapping(value="testTransaction",produces="text/plain;charset=UTF-8")
	/**
	 * 字典表分页查询
	 * @param page
	 * @param size
	 * @return
	 */
	@RequestMapping(value = "selByPage")
	@ResponseBody
	public ResultDTO selDictByPage(
			@RequestParam(name = "page", defaultValue = "1", required = true) int page,
			@RequestParam(name = "size", defaultValue = "10") int size) {
		// 日志
		logger.info(String.format("字典表分页查询,请求参数,page:%s;size:%s", page, size));

		PageInfo<Map<String, Object>> pageInfo = dictService.selDictByPage(page, size);
		
		HashMap<String, Object> m = new HashMap<String, Object>();
		m.put(SysConstant.BSY_DATA_TOTAL_NAME, pageInfo.getTotal());
		m.put(SysConstant.BSY_DATA_INFO_NAME, pageInfo.getList());

		return ResultUtil.success(m);
	}

}
