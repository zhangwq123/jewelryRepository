package com.jewelry.controller;

import java.io.IOException;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.jewelry.config.ResultUtil;
import com.jewelry.config.dto.ResultDTO;
import com.jewelry.config.pojo.Sysmenu;
import com.jewelry.service.SysMenuService;

/**
 * 菜单   测试
 * @author zwq
 */
@Controller
@RequestMapping("/menu")
public class SysmenuController {
	Logger logger = Logger.getLogger(SysmenuController.class);
	@Autowired
	SysMenuService sysMenuService;

	/**
	 * 用户登录
	 * 
	 * @param uname
	 * @param pwd
	 * @return
	 * @throws IOException 
	 */
	@RequestMapping(value = "selAll")
	@ResponseBody
	public ResultDTO login()  {
		List<Sysmenu> list = sysMenuService.selAllSysMenuContainChild();
		// 日志
		logger.info(String.format("菜单测试:"+list));
		
		return ResultUtil.success(list);

	}
}
