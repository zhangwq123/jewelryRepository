package com.jewelry.controller;

import java.io.IOException;
import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.aspectj.weaver.ast.HasAnnotation;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.jewelry.config.ResultUtil;
import com.jewelry.config.SysConstantEnum;
import com.jewelry.config.dto.ResultDTO;
import com.jewelry.util.ValidateUtil;

/**
 * 用户登录处理
 * @author zwq
 */
@Controller
@RequestMapping("/user")
public class UserLogin {
	Logger logger = Logger.getLogger(UserLogin.class);

	/**
	 * 用户登录
	 * 
	 * @param uname
	 * @param pwd
	 * @return
	 * @throws IOException 
	 */
	@RequestMapping(value = "login")
	@ResponseBody
	public ResultDTO login(@RequestParam(name = "uname", required = true) String uname,
			@RequestParam(name = "pwd", required = true) String pwd, HttpServletRequest req) {
		// 日志
		logger.info(String.format("用户登录,请求参数,uname:%s;pwd:%s", uname, pwd));
		// 返回数据
		HashMap<String, String> m = new HashMap<String, String>();
		m.put("uname", "测试用户名");
		m.put("uno", "1001");

		// 创建session 将user 放入session
		HttpSession session = req.getSession(false);
		if(session==null){//未登录
			session = req.getSession(true);
			logger.info("未登录，创建sessionid成功:"+session.getId());
			session.setAttribute("user", m);
		}
		logger.info(String.format("当前sessionid:%s", session.getId()));
		return ResultUtil.success(m);
	}
}
