package com.jewelry.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * 用户退出登录处理
 * 
 * @author zwq
 *
 */
@Controller
@RequestMapping("/user")
public class UserLogout {

}
