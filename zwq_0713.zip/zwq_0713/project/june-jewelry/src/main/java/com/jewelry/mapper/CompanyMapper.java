package com.jewelry.mapper;

import org.apache.ibatis.annotations.Param;

import com.jewelry.config.pojo.Company;

public interface CompanyMapper {

	public Company queryById(@Param("coId")Integer coId);
}
