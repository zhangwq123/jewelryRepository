package com.jewelry.mapper;

import java.util.List;
import java.util.Map;

public interface DictMapper {
	
	/**
	 * 分页查询
	 * @return
	 */
	List<Map<String,Object>> selDictByPage();

}
