package com.jewelry.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Select;

import com.jewelry.config.pojo.Sysmenu;

/**
 * 系统菜单
 * @author zwq
 *
 */
public interface SysMenuMapper {
	
	@Select("select * from je_sysmenu where mn_isshow='0' order by mn_sort asc")
	List<Sysmenu> selAllMenu();

}
