package com.jewelry.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import com.jewelry.config.pojo.Company;
import com.jewelry.mapper.CompanyMapper;

@Service
public class CompanyService {

	@Autowired
	private CompanyMapper mapper;
	
	@Cacheable("default")
	public Company queryInfoById(Integer coId) {
		System.out.println("123");
		return mapper.queryById(coId);
	}
}
