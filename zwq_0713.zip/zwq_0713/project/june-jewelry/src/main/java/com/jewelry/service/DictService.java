package com.jewelry.service;

import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.jewelry.config.SysConstant;
import com.jewelry.config.exception.TransFailException;
import com.jewelry.mapper.DictMapper;

@Service
public class DictService {
	Logger logger = Logger.getLogger(DictService.class);
	@Autowired
	DictMapper dictMapper;

	/**
	 * 字典表分页查询
	 * 
	 * @param page
	 * @param size
	 * @return
	 */
	public PageInfo<Map<String, Object>> selDictByPage(Integer page, Integer size) {

		PageInfo<Map<String, Object>> pageInfo = null;
		try {
			page = page == null ? 1 : page;
			size = size == null ? SysConstant.DEFAULT_PAGE_SIZE : size;
			PageHelper.startPage(page, size);
			List<Map<String, Object>> dataList = dictMapper.selDictByPage();
			pageInfo = new PageInfo<Map<String, Object>>(dataList);
		} catch (Exception e) {
			logger.error("分页查询字典表异常", e);
			throw new TransFailException("xs", "数据库错误");
		}
		return pageInfo;

	}

}
