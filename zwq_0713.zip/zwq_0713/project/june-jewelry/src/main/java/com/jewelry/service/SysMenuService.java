package com.jewelry.service;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import com.jewelry.config.pojo.Sysmenu;
import com.jewelry.mapper.SysMenuMapper;

/**
 * 系统菜单服务
 * @author zwq
 *
 */
@Service
public class SysMenuService {
	Logger logger = Logger.getLogger(SysMenuService.class);
	@Autowired
	SysMenuMapper sysMenuMapper;
	
	/**
	 * 返回所有系统显示菜单
	 * @return
	 */
	@Cacheable("contextCache")
	public List<Sysmenu> selAllSysMenu(){
		return sysMenuMapper.selAllMenu();
	};
	
	/**
	 * 返回所有系统显示菜单  层级关系
	 * @return
	 */
	@Cacheable("contextCache")
	public List<Sysmenu> selAllSysMenuContainChild(){
		//所有菜单
		 List<Sysmenu> all_menu = selAllSysMenu();
		 //一级菜单
		 ArrayList<Sysmenu> one_menu_list = new ArrayList<Sysmenu>();
		
		 //一级
		 for (Sysmenu s : all_menu) {//一级菜单pid=0
			if("0".equals(s.getMn_pid())){
				one_menu_list.add(s);
			}
		}
		 
		 for (Sysmenu ss : one_menu_list) {
			 ss.setChildmenus(getChildMenus(ss.getMn_id(), all_menu));
		}
		return one_menu_list;
	};
	
	/**
	 * 递归查询当前菜单子菜单
	 * 
	 * @param id
	 * @param dataList
	 *            菜单域
	 * @return
	 */
	private static List<Sysmenu> getChildMenus(String id, List<Sysmenu> dataList) {
		// 子菜单
		ArrayList<Sysmenu> childMenus = new ArrayList<Sysmenu>();
		for (Sysmenu menu : dataList) {
			if (menu.getMn_pid().equals(id)) {
				childMenus.add(menu);
			}
		}
		// 子菜单再循环
		for (Sysmenu menu : childMenus) {
			if ("0".equals(menu.getMn_isparent())) {// 0 为父菜单
				menu.setChildmenus(getChildMenus(menu.getMn_id(), dataList));
			}
		}
		// 退出
		if (childMenus.size() == 0) {
			return null;
		}
		return childMenus;
	}

}
