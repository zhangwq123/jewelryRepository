package com.jewelry.util;


import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;

public class HibernateValidateUtil {
	private static Validator validator = null;

	 static { 
	        ValidatorFactory factory = Validation.buildDefaultValidatorFactory(); 
	        validator = factory.getValidator(); 
	    } 

	public static <T> String validateCustomObj(T t) {
		Set<ConstraintViolation<T>> set = validator.validate(t);
		String msg = "";
		for (ConstraintViolation<T> cs : set) {
			msg += cs.getMessage() + ";";
		}
		return msg;
	}
	
	
}
