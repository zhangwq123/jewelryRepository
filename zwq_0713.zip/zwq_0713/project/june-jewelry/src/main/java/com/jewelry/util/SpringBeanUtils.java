package com.jewelry.util;

import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Component;

@Component
public class SpringBeanUtils implements ApplicationContextAware {

	private ApplicationContext applicationContext;
	private static SpringBeanUtils instance;

	public static SpringBeanUtils getInstance() {
		return instance;
	}

	@Override
	public void setApplicationContext(ApplicationContext context) throws BeansException {
		this.applicationContext = context;
		instance = this;
	}

	public ApplicationContext getApplicationContext() {
		return applicationContext;
	}

	@SuppressWarnings("unchecked")
	public <T> T getBean(String name) throws BeansException {
		return (T) this.applicationContext.getBean(name);
	}

	public <T> T getBeanOfType(String name, Class<T> requiredType) throws BeansException {
		return (T) this.applicationContext.getBean(name, requiredType);
	}
}
