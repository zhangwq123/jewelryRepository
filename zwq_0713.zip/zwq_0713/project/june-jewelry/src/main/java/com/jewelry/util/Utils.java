package com.jewelry.util;

import java.io.IOException;
import java.io.Writer;

import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.alibaba.fastjson.JSON;

public class Utils {
	
	private static Logger logger = Logger.getLogger(Utils.class);
	
    /**
     * @param response
     * @param data
     */
    public static void responseMessage(HttpServletResponse response, Object data) {
        response.setContentType("application/json; charset=utf-8");
        
        Writer wr = null;
		try {
			wr = response.getWriter();
			String str = data instanceof String ? (String)data : JSON.toJSONString(data);
			wr.write(str);
			wr.flush();
			wr.close();
		} catch (IOException e) {
			logger.error("返回数据时打开Writer失败", e);
			
		} finally {
			if (wr != null) {
				try {
					wr.flush();
					wr.close();
				} catch (IOException e) {
					logger.error("返回数据时关闭Writer失败", e);
				}
			}
		}
    }
}
