package com.jewelry.util;

import com.jewelry.config.SysConstantEnum;
import com.jewelry.config.exception.TransFailException;

/**
 * 校验工具
 * @author zwq
 *
 */
public class ValidateUtil {
	/**
	 * 多个域必输   与选送字段长度  和非空校验
	 * strList,fieldIsNeed ,fieldMaxLen,errCodeList, errMsgList
	 * @param strList	
	 *            被检查字段
	 * @param fieldIsNeed	
	 *            被检查字段是否必输	Y   N
	 * @param fieldMaxLen
	 *            被检查字段最大允许字节长度  utf-8编码
	 * @param errCodeList
	 *            对应错误码信息
	 * @param errCodeList
	 *            errMsgList
	 * @return
	 * @throws TransFailException
	 */
	public static void checkNullAndLength(String[] strList, String[] fieldIsNeed, int[] fieldMaxLen, String[] errCodeList, String[] errMsgList) throws TransFailException {
		int a=strList.length;
		int b=fieldIsNeed.length;
		int c=fieldMaxLen.length;
		int d=errCodeList.length;
		int e=errMsgList.length;
		if (a == b && b == c&& c == d&& d == e) {
			for (int i = 0; i < strList.length; i++) {
				String v=strList[i];
				String isNeed=fieldIsNeed[i];
				int len=fieldMaxLen[i];
				if("Y".equals(isNeed)){//必送字段
					try {
						if (v == null || v.trim().getBytes("utf-8").length == 0||v.trim().getBytes("utf-8").length>len) {
							throw new TransFailException(errCodeList[i], errMsgList[i]);
						}
					} catch (Exception e1) {
						throw new TransFailException(errCodeList[i], errMsgList[i]);
					}
				}else{//选送字段
					try {
						if (v != null &&v.trim().getBytes("utf-8").length>len) {
							throw new TransFailException(errCodeList[i], errMsgList[i]);
						}
					} catch (Exception e1) {
						throw new TransFailException(errCodeList[i], errMsgList[i]);
					}
				}
				
			}
		} else {//默认系统错误
			throw new TransFailException(SysConstantEnum.SYS_ERR.getCode(), SysConstantEnum.SYS_ERR.getMsg());
		}
	}

}
