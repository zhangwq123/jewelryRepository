DROP TABLE IF EXISTS `test_tb`;

CREATE TABLE `test_tb` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT  COMMENT 'id',
  `usr_name` varchar(200) NOT NULL COMMENT '����',
  `usr_user_id` bigint(20) NOT NULL COMMENT '�û���',
  `gmt_modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '�޸�ʱ��',
  PRIMARY KEY (`id`),
  KEY `auto_shard_key_usr_user_id` (`usr_user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=200002 DEFAULT CHARSET=utf8 COMMENT='���Ա�' ;

/*Data for the table `test_tb` */

LOCK TABLES `test_tb` WRITE;



UNLOCK TABLES;

insert  into `test_tb`(`usr_name`,`usr_user_id`) values ('zwq',001);